<?php
print str_shuffle(md5(microtime()));
?>