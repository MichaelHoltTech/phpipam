<?php

/**
 * API parameters for testing
 */

# URL
$url    = "http://devel.phpipam.net/api/v1/";

# APPID and encryption key
$app['id']	= "test345";
$app['enc']	= "6fd985a8324fcf114d3fb46886ea46ef";

# set response type - array, json
$format		= "array";

?>