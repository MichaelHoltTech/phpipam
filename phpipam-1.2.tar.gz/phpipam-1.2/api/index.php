<?php

/**
 *
 * Default API version links to v2
 *
 */

# include
require("v2/index.php");
?>